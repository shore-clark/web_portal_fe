<?php
$url = 'http://10.128.187.11';
$token = $_POST['token'];
$json = file_get_contents($url.'/web/web_portal_be/api/cost_centre?token='.$token); 
$data = json_decode($json,true);
$devices = $data['message'];

foreach ($devices as $device)
{
	$costCentreName = $device['cost_centre_name'];
	$costCentreParentID = $device['cost_centre_parent_id'];
	$newarr = array($costCentreParentID, $costCentreName);
	if (in_array("0", $newarr)) {

		echo '<li class="has-sub">
                <a class="js-arrow" href="#">
                    <i class="fas fa-folder"></i> <i class="fas fa-plus"></i>'.$costCentreName.'</a>
                	<ul>
                		<li>Branch 1</li>
                		<li>Branch 2</li>
                	</ul>
            	</li>';

	}

}


?>