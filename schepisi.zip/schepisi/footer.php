
    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>
        <!--pagination scripts-->
    <script type="text/javascript" src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<!-- end pagination scripts -->
    <!-- Main JS-->
    <script type="text/javascript">
        
        $(document).ready(function(){
                $('#chargers_and_credit').change(function(){
                    $('#jsonOutput').text('');
                    UploadIt('chargers_and_credit');
                })
                $('#call_and_usage').change(function(){
                    $('#jsonOutput').text('');
                    UploadIt('call_and_usage');
                })
                $('#service_and_equipment').change(function(){
                    $('#jsonOutput').text('');
                    UploadIt('service_and_equipment');
                })
                organizationControls();
                onLoadData();
                uploadBtn();

        });
    </script>


    <script src="js/main.js"></script>
    <script src="assets/js/chkSession.js"></script>
    <script src="assets/js/scripts.js"></script>

<script type="text/javascript" src="https://cdn.anychart.com/releases/8.7.0/js/anychart-base.min.js"></script>
<script type="text/javascript" src="https://cdn.anychart.com/releases/8.7.0/js/anychart-exports.min.js"></script>
<script type="text/javascript" src="https://cdn.anychart.com/releases/8.7.0/js/anychart-ui.min.js"></script>

    <script type="text/javascript">

    anychart.onDocumentReady(function () {
/* monthly billing */
    $.ajax({
        type: 'POST',
        data:{
            token: sessionStorage.getItem('token'),
            type: 'month'
        },

        //url: 'http://10.128.187.11/web/web_portal_be/reports/accounts/month?token='+sessionStorage.getItem('token'),
        //dataType: 'json',
        url: 'monthlyBilling.php',
        success: function(data, index){    
               
            $('.overview-wrap').append(data);
            jsonData = {
                    // chart settings
                    "chart": {
                      // chart type
                      "type": "pie",
                      // chart data
                      "data": [
                            {"x": "Call and Usage", "value": $('#callandusageTxt').text(), fill: "green"},
                            {"x": "Chargers and Credit", "value": $('#chargersandcreditTxt').text(), fill: "orange"},
                            {"x": "Service and Equipment", "value": $('#serviceandequipmentTxt').text(), fill: "blue"}
                      ],
                      // chart container
                      "container": "pieChartContainer"
                    }
                  };
                   pieChart = anychart.fromJson(jsonData); 
                    pieChart.draw();
                    $('.anychart-credits').remove();
                
                $('#pieChartContainer').find('[fill=orange]').addClass('chargers');
                $('#pieChartContainer').find('[fill=green]').addClass('usage');
                $('#pieChartContainer').find('[fill=blue]').addClass('service');
                $('.usage').click(function(){
                    $.ajax({
                        type: 'POST',
                        data:{
                            token: sessionStorage.getItem('token'),
                            click: $(this).attr('class')
                        },

                        url: 'monthlyBilling.php',
                        success: function(data, textStatus ){
                            var usageDiv = $('#pieChartContainer').find('[fill=green]');
                            if(usageDiv.hasClass('active')){
                                usageDiv.removeClass('active');
                                $('#pieChartData > ul').empty();
                            }
                            else{
                                usageDiv.addClass('active');
                                $('#pieChartData > ul').empty().append("<div>"+data+"</div>");
                            }
                            //console.log($('#chargers_and_credit-table > tr').length);
                            
                        },
                        error: function(xhr, textStatus, errorThrown){
                           $('#submitOrganization').text('Submit');

                        }
                    });
                    
                });

                $('.chargers').click(function(){
                     $.ajax({
                        type: 'POST',
                        data:{
                            token: sessionStorage.getItem('token'),
                            click: $(this).attr('class')
                        },

                        url: 'monthlyBilling.php',
                        success: function(data, textStatus ){
                            var chargeDiv = $('#pieChartContainer').find('[fill=orange]');
                            if(chargeDiv.hasClass('active')){
                                chargeDiv.removeClass('active');
                                $('#pieChartData > ul').empty();
                            }
                            else{
                                chargeDiv.addClass('active');
                                $('#pieChartData > ul').empty().append("<div>"+data+"</div>");
                            }
                            //console.log($('#chargers_and_credit-table > tr').length);
                            
                        },
                        error: function(xhr, textStatus, errorThrown){
                           $('#submitOrganization').text('Submit');

                        }
                    });
                    
                });

                $('.service').click(function(){
                    $.ajax({
                        type: 'POST',
                        data:{
                            token: sessionStorage.getItem('token'),
                            click: $(this).attr('class')
                        },

                        url: 'monthlyBilling.php',
                        success: function(data, textStatus ){
                            var serviceDiv = $('#pieChartContainer').find('[fill=blue]');
                            if(serviceDiv.hasClass('active')){
                                serviceDiv.removeClass('active');
                                $('#pieChartData > ul').empty();
                            }
                            else{
                                serviceDiv.addClass('active');
                                $('#pieChartData > ul').empty().append("<div>"+data+"</div>");
                            }
                            //console.log($('#chargers_and_credit-table > tr').length);
                            
                        },
                        error: function(xhr, textStatus, errorThrown){
                           $('#submitOrganization').text('Submit');

                        }
                    });
                    
                });


        },
        error: function(xhr, textStatus, errorThrown){
           console.log(textStatus);

        }
    });
/* end monthly billing */
    /* annual billing */
        $.ajax({
        type: 'GET',
        data:{
            token: sessionStorage.getItem('token'),
            type: 'year'
        },

        url: 'http://10.128.187.11/web/web_portal_be/reports/accounts/year?token='+sessionStorage.getItem('token'),
        //dataType: 'json',
        //url: 'annualBilling.php',
        success: function(data, index){            
            //$('.overview-wrap').append(data);
            // create data set on our data
            chartData = {
                header: ['#', 'Call and Usage', 'Chargers and Credit', 'Service and Equipment'],
                rows: data
            };

            // create column chart
            var chart = anychart.column();

            // set chart data
            chart.data(chartData);

            // turn on chart animation
            chart.animation(true);

            // force chart to stack values by Y scale.
            chart.yScale().stackMode('value');

            // chart padding
            chart.padding([10, 20, 5, 20]);

          
            chart.xAxis(1).stroke(null)
                    .orientation('top');
            chart.yAxis(0).labels().format('${%Value}');

            // zero marker line
            var zeroMarker = chart.lineMarker(0);
            zeroMarker.stroke('#ddd');
            zeroMarker.scale(chart.yScale());
            zeroMarker.value(0);

            // enable and tune grid
            chart.xGrid()
                    .stroke('#ddd')
                    .drawLastLine(false);

            // tune paddings
            chart.barsPadding(0.1)
                    .barGroupsPadding(0.9);

            // turn on legend and set settings
            chart.legend()
                    .enabled(true)
                    .fontSize(13)
                    .padding([0, 0, 20, 0]);

            chart.interactivity().hoverMode('by-x');
            chart.tooltip().displayMode('union');

            // set container id for the chart
            chart.container('barChartContainer');

            // initiate chart drawing
            chart.draw();
            $('.anychart-credits').remove();


        },
        error: function(xhr, textStatus, errorThrown){
           console.log(textStatus);

        }
    });
    /* end annual billing */

});


    </script>

</body>

</html>
<!-- end document-->

