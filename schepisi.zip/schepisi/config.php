<?php
$url = "http://10.128.187.11";
 echo $url;
?>