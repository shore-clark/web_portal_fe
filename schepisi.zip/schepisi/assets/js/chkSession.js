
function logout(){
	var sessionURL = sessionStorage.getItem('url');
	sessionStorage.removeItem('token');
	sessionStorage.removeItem('username');
	sessionStorage.removeItem('role');
	window.location.href= "http://10.128.187.12/schepisi/";
}

$(document).ready(function(){
	var sesUser = sessionStorage.getItem('username');
	var sesToken = sessionStorage.getItem('token');
	var sesRole = sessionStorage.getItem('role');
	var orgname = sessionStorage.getItem('orgName');
	if(sesUser != null && sesToken != null && sesRole != null && orgname != null){
		$('#userName').html(sesUser);
		//console.log(sessionStorage.token);
		$('.userRole').find('.email').text(sesRole.toUpperCase() + ' ' +'user'.toUpperCase());
		$('.orgname').find('.organization').text(orgname.replace(/_/g, ' ').toUpperCase());

	}
	else{
		window.location.href= "http://10.128.187.11/schepisi/";
	}
	

	$('#logout').click(function(){
		 logout();
	})

	         
    window.onload = reset_main_timer;
    document.onmousemove = reset_main_timer;
    document.onkeypress = reset_main_timer;
    
    // create main_timer and sub_timer variable with 0 value, we will assign them setInterval object
    var main_timer = 0;
    var sub_timer = 0;

 
    var user_logged_in = $("#user_logged_in").val()

    function dialog_set_interval(){
    	var autologout = 30 * 60 * 1000;
        main_timer = setInterval(function(){
            if(user_logged_in == "true"){
                
                sub_timer = setInterval(function(){
                    	sessionStorage.removeItem('token');
						sessionStorage.removeItem('username');
						sessionStorage.removeItem('role');
						sessionStorage.setItem('session','expired');
						window.location.href= "http://10.128.187.12/schepisi/"
						
                },autologout);

            }
        },500);
    }
    function reset_main_timer(){
        clearInterval(main_timer);
        dialog_set_interval();
    }
    $(".inactivity_ok").click(function(){
        clearInterval(sub_timer);
        if($("#user_activity").val() == "inactive"){
            window.location = window.location 
        }
    });

});